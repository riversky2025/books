class Book:
    """Information about a book.
    """
