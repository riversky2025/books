>>> lobster = Arthropod('Homarus gammarus', 0, 0)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: __init__() takes exactly 5 arguments (4 given)
>>> lobster = Arthropod('Homarus gammarus', 0, 0, 10)
