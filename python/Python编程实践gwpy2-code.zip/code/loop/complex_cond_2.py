def f(a, b, c):
  if a and b:
    print('hi')
  elif a and c:
    print('bonjour')
  elif a:
    print('hola')
  else:
    print('Select a language')
