print("__name__ is", __name__)
