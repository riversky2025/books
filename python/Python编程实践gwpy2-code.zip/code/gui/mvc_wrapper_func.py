def click_up():
    click(counter, 1)

def click_down():
    click(counter, -1)
