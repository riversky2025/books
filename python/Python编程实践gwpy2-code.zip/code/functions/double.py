def get_double_num(x):
    """ (number) -> number

    Return x doubled.

    >>> double_num(4)
    8
    """
    
    return x * 2


def double_num(x):
    """ (number) -> NoneType

    Double x.

    >>> double_num(3)
    """
    
    x * 2
